# ImageEditor
Simple Python Image Editor
Helps you change contrast and blur with the help of slider , Can flip image on x and y axis. Enables you to use various filters such as Emboss and Contour.You can save the same on your computer.
